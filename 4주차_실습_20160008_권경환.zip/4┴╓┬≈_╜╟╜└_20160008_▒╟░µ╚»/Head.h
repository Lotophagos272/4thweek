#include <iostream>
#include <string.h>

using namespace std;

template <typename T>

class Node{
public:
	T data;
	Node<T> *link;
	Node(T element){
	data=element;
	link=0;
	};
};
template < typename T >
class LinkedList{
protected:
	Node<T> *first;
	int current_size;
public:
	LinkedList(){
		first=0;
		current_size=0;};
	int GetSize(){return current_size;};
	void Insert(T element){
		Node<T>* newnode = new Node<T>(element);
		newnode->link = first;
		first = newnode;
		current_size++;
	};
	virtual bool Delete(T &element){
		if(first==0)return false;
		Node<T> *current = first, *previous=0;
		while(1){
			if(current->link==0)
			{
				if(previous)previous->link=current->link;
				else first=first->link;
				break;
			}
		previous = current;
		current = current->link;
		}
		element = current->data;
		delete current;
		current_size--;
		return true;
	};

	void Print(){
		if(first==0)return;
		int pri=2;
		Node<T> *current;
		current=first->link;
		cout<<"[1|"<<first->data<<"]";
		for(pri=2;pri<=current_size;pri++){
			cout<<"->["<<pri<<"|"<<current->data<<"]";
			current=current->link;
		}
		cout<<endl;
		return;};
	};
template <typename T>
class Stack : public LinkedList<T>{
public:
	virtual bool Delete(T &element){
		if(this->first==0)return false;
		Node<T> *current=this->first;
		this->first=current->link;
		element=current->data;
		delete current;
		this->current_size--;
		return true;};
};
/*
template<typename T>
void LinkedList<T>::Insert(T element){
	Node<T>* newnode = new Node<T>(element);
	newnode->link = first;
	first = newnode;
	current_size++;
}
template<typename T>
bool LinkedList<T>::Delete(T &element){
	if(first==0)return false;
	Node<T> *current = first, *previous=0;
	while(1){
		if(current->link==0)
		{
			if(previous)previous->link=current->link;
			else first=first->link;
			break;
		}
		previous = current;
		current = current->link;
	}
	element = current->data;
	delete current;
	current_size--;
	return true;
}
template <typename T>
void LinkedList<T>::Print(){
int pri=1;
Node<T> *current;
for(pri=1;pri<=current_size;pri++){
cout<<"["<<pri<<"|"<<current<<"]->";
pri++;
current=current->link;
}
cout<<endl;
}
template <typename T>
bool Stack<T>::Delete(T &element){
if(this->first==0)return false;
Node<T> *current=this->first;
this->first=current->link;
element=current->data;
delete current;
this->current_size--;
return true;
}
*/
